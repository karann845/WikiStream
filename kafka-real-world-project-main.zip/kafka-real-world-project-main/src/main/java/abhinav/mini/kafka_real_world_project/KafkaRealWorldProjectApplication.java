package abhinav.mini.kafka_real_world_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaRealWorldProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaRealWorldProjectApplication.class, args);
	}

}
