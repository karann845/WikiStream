package abhinav.mini.kafka_real_world_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaRealWorldProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
